With all of the best intentions to be charitable, we also need to make sure that our money and effort gets to the causes we intend to support.

Our friends at Imagine Canada provide a very useful <a href="https://www.imaginecanada.ca/en/guide-to-giving">Guide to Giving</a>. Check it out for some great suggestions and resources.