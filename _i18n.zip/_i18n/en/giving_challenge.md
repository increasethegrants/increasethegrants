The Great Canadian Giving Challenge is a public contest to benefit any registered Canadian charity, occurring annually in June. Every $1 donated to a registered charity on CanadaHelps.org, automatically enters the charity to win a $10,000 donation awarded on Canada Day.

Check out the latest impact results from The Great Canadian Giving Challenge by visiting the website below.
