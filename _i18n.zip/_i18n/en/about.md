GIV3 is a privately-registered Canadian charity<sup>[1](#contact)</sup>, though we do not
ask for donations from Canadians. Instead, we encourage everybody to be more giving by
volunteering and donating to registered charities of their choice.
 
The movement stands on three pillars: **G**iving, **I**nspiring others and **V**olunteering. 
GIV3 engages Canadian charities and the public in activities to encourage these behaviours. 

