GivingTuesday is a global day of giving that falls annually after Black Friday and Cyber Monday. GIV3 and CanadaHelps are co-founders of GivingTuesday in Canada. The movement now engages more than 7,000 charities and businesses and millions of Canadians from coast to coast to coast.

Check out the latest impact results from GivingTuesday by visiting the website below.