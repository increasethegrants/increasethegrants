GIV3 does not solicit funds from the public to help us do our work – we simply ask people to give or volunteer for the charities of their own choice. In order to maintain our programs we rely on support from private sources. We are very grateful to the following for their generous financial support, in-kind support and/or collaboration:

- John Hallward
- Sector3Insights
- J. W. McConnell Family Foundation
- R. Howard Webster Foundation
- Zeller Foundation
- Foundation of Greater Montreal
- Vancouver Foundation
- Toronto Foundation
- CanadaHelps.org
- Canadian Association of Gift Planners (CAGP)
- Philanthropic Foundations of Canada (PFC)