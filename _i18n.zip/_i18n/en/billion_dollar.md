All of the GIV3 programs to date are part of a greater vision: The Billion Dollar Opportunity.  This is a multi-year, multi-faceted vision to inspire more giving, similar to ParticipACTION, but for the non-profit sector. 

If Canadians returned to their giving behaviour of a generation ago, at just 1% of their taxable income (up from today’s 0.7% average), it would generate in excess of $2 BILLION more for the sector annually. This requires long-term thinking and will likely take a generation to reverse our current declining charitable behaviour, but the size of the opportunity compels us all to try. A generation ago almost nobody recycled or composted – now most of us do it! 

Please contact us to discuss this idea further.