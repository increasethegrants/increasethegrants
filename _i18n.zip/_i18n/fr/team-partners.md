Nous ne sollicitons pas de fonds auprès du grand public. Afin de soutenir nos programmes, nous comptons sur le soutien de donateurs privés ainsi que des fondations. Nous sommes très reconnaissants à ces organismes pour leur soutien financier généreux et/ou leur collaboration

- John Hallward
- Sector3Insights
- Fondation de la famille J. W. McConnell
- Fondation R. Howard Webster
- Fondation Zeller
- Fondation du Grand Montréal
- Fondation DONN3
- CanaDon.org
- Association canadienne des professionnels en dons planifiés (ACPDP)
- Fondations Philanthropiques Canada (FPC)